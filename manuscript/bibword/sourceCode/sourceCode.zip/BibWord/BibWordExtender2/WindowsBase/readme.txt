This is a version of WindowsBase for Mac OS X.

It is the Mono implementation of 14/3/2009 together with a number of custom patches. The patches have been submitted to the Mono project but not yet integrated into their source. Therefore, do not use a version of this dll retrieved in any other fashion from them. Once an official release is made by them (expected September 2009), their dll will be tested with BibWordExtender.

Place WindowsBase.dll in the same directory as BibWordExtender2.