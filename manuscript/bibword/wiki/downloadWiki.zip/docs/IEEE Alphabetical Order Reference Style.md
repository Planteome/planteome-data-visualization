## IEEE Alphabetical Order Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Requirements](#A3)
* [Based On](#A4)
* [Supported Types](#A5)
* [Variations](#A6)
#### Description{anchor:A1}
Implementation of the IEEE reference style. This style uses numeric in-text citations based on their alphabetical order in the entire list of sources.

As the current version of the bibliography tools in Word 2007 does not support this directly, you will have to use the [release:BibOrder](17130) tool to achieve the numbering.

Examples:
{{
 [1](1) N. H. F. Beebe. (2006, August) TeX User Group Bibliography Archive. [Online](Online). 
     http://www.math.utah.edu:8080/pub/tex/bib/index-table.html
 [2](2) J. C. Candy and G. C. Temes, Eds., Oversampling Delta-Sigma Data Converters Theory, 
     Design and Simulation. New York, U.S.: IEEE Press, 1992.
 [3](3) B. D. Cullity, Introduction to Magnetic Materials. Reading, MA: Addison-Wesley, 1972.
     ...
[16](16) D. Middleton and A. D. Spaulding, "A Tutorial Review of Elements of Weak Signal Detection 
     in Non-Gaussian EMI Environments," National Telecommunications and Information Administration 
     (NTIA), U.S. Dept. of Commerce, NTIA Report 86-194, 1986.
[19](19) J. Padhye, V. Firoiu, and D. Towsley, "A Stochastic Model of TCP Reno Congestion Avoidance 
     and Control," Univ. of Massachusetts, Amherst, CMPSCI Tech. Rep. 99-02, 1999.
}}
#### File{anchor:A2}
IEEE_Alphabetical.xsl - the file can be found in the [release:styles](15852) collection.
#### Requirements{anchor:A3}
* [release:BibOrder](17130)
#### Based On{anchor:A4}
* [IEEE style manual](http://www.ieee.org/portal/cms_docs_iportals/iportals/publications/authors/transjnl/stylemanual.pdf);
* [IEEE standards style manual](http://standards.ieee.org/guides/style/2007_Style_Manual.pdf);
* [IEEEtran.bst stylesheet for LaTeX](http://www.ctan.org/get/macros/latex/contrib/IEEEtran/bibtex/IEEEtran.bst).
#### Supported Types{anchor:A5}
The current version of the style supports the following types and subtypes.
* ArticleInAPeriodical
* Book
* BookSection
* ConferenceProceedings
* DocumentFromInternetSite
* ElectronicSource
* InternetSite
* JournalArticle 
* Misc
* Patent
* Report
	* Standard
	* Thesis
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Variations{anchor:A6}
* You can change the surrounding brackets for in-text citations by changing the contents of the **openbracket** and **closebracket** elements. 
{code:xml}
  <citation>
    <openbracket>(</openbracket>
    <closebracket>)</closebracket>
    ...
  </citation>
{code:xml}
* You can change the look of the numbers in the first column of the bibliography by changing the **format** element of the first column _(column id="1")_. Note that you have to do this for each type separately. Some examples are:
{code:xml}
  <!-- Number between square brackets (current implementation). Example: [1](1) -->
  <format>{[%RefOrder%](%RefOrder%)}</format>
  <!-- Number between round brackets. Example: (1) -->
  <format>{(%RefOrder%)}</format>
  <!-- Number followed by a period. Example: 1. -->
  <format>{%RefOrder%.}</format>
{code:xml}