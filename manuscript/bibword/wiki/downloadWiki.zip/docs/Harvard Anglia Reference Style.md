## Harvard Anglia Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Based On](#A3)
* [Supported Types](#A4)
* [Remarks](#A5)
#### Description{anchor:A1}
Implementation of the Harvard reference style. As the Harvard reference style is only defined as an _(author, date)_ reference style, its specification varies. This is an implementation based on the guidelines of the Anglia Rushkin University.

Examples:
{{
Breckling, J. ed., 1989. The Analysis of Directional Time Series: Applications to Wind Speed and
Direction. Berlin: Springer.

Bul, B. K., 1964. In Theory Principles and Design of Magnetic Circuits. Moscow: Energia Press. p. 464.

Candy, J. C. & Temes, G. C. eds., 1992. Oversampling Delta-Sigma Data Converters Theory, Design
and Simulation. New York: IEEE Press.

Cullity, B. D., 1972. Introduction to Magnetic Materials. Reading: Addison-Wesley.

Dawson, R. M. A. et al., 1998. Design of an Improved Pixel for a Polysilicon Active-Matrix Organic
LED Display. In SID Tech. Dig. p. 11-14.
}}
#### File{anchor:A2}
HarvardAnglia.xsl - the file can be found in the [release:styles](15852) collection
#### Based On{anchor:A3}
* [http://www.leeds.ac.uk/library/training/referencing/harvard.htm](http://www.leeds.ac.uk/library/training/referencing/harvard.htm)
#### Supported Types{anchor:A4}
The current version of the style supports the following types and subtypes.
* Book
* BookSection
* ConferenceProceedings
* Film
* InternetSite
* JournalArticle
* Report
#### Remarks{anchor:A5}
Currently, there is no support for year suffixes in case the same author published multiple works in the same year.