## Harvard Leeds Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Based On](#A3)
* [Supported Types](#A4)
* [Remarks](#A5)
#### Description{anchor:A1}
Implementation of the Harvard reference style. As the Harvard reference style is only defined as an _(author, date)_ reference style, its specification varies. This is an implementation for the specification at Leeds University.

Examples:
{{
COATES, M., A. HERO, R. NOWAK, and B. YU. 2002. Internet Tomography. IEEE Signal Process. Mag.

CULLITY, B. D. 1972. Introduction to Magnetic Materials. Reading: Addison-Wesley.

DAWSON, R. M. A., Z. SHEN, and D. A. FURST et al. 1998. Design of an Improved Pixel for a Polysilicon
Active-Matrix Organic LED Display. In: SID Tech. Dig., pp.11-14.

DELORME, F. and OTHERS. 1995. Butt-joined DBR Laser With 15 nm Tunability Grown in Three MOVPE
Steps. Electron. Lett. 31(15), pp.1244-1245.

FINN, S. G., M. MÉDARD, and R. A. BARRY. 1997. A Novel Approach to Automatic Protection Switching 
Using Trees. In: Proc. Int. Conf. Commun., 1997.

GUPTA, R. K. and S. D. SENTURIA. 1997. Pull-in Time Dynamics as a Measure of Absolute Pressure. 
In: Proc. IEEE International Workshop on Microelectromechanical Systems (MEMS'97), 1997. Nagoya, 
Japan:, pp.290-294.
}}
#### File{anchor:A2}
HarvardLeeds.xsl - the file can be found in the [release:styles](15852) collection
#### Based On{anchor:A3}
* [http://www.leeds.ac.uk/library/training/referencing/harvard.htm](http://www.leeds.ac.uk/library/training/referencing/harvard.htm)
#### Supported Types{anchor:A4}
The current version of the style supports the following types and subtypes.
* Art
* ArticleInAPeriodical
* Book
	* ElectronicBook
* BookSection
* ConferenceProceedings
* Case
* DocumentFromInternetSite
* ElectronicSource
* Film
* InternetSite
	* AnonymousInternetSite
	* Blog
* Interview
* JournalArticle
	* ElectronicJournalArticle
* Misc
* Patent
* Performance
* Report
	* Standard
	* Thesis
* SoundRecording
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Remarks{anchor:A5}
As of the upgrade to BibWord v.1.5, year suffices are now supported. To use them, the [release:BibWord Extender](19474) is required.