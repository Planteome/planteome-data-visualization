## Association for Computing Machinery Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Supported Types](#A4)
* [Variations](#A5)
#### Description{anchor:A1}
Implementation of the Association for Computing Machinery (ACM) reference style.

Examples:
{{
6   Candy, J. C. and Temes, G. C., eds. Oversampling Delta-Sigma Data Converters Theory, 
    Design and Simulation. IEEE Press., New York, 1992.
    ...
13  Hedelin, P., Knagenhjelm, P., and Skoglund, M. Theory for Transmission of Vector Quantization 
    Data. In Kleijn, W. B. and Paliwal, K. K., eds., Speech Coding and Synthesis. Elsevier Science, 
    Amsterdam, 1995.
14  Dawson, R. M. A., Shen, Z., and Furst, D. A. et al. Design of an Improved Pixel for a Polysilicon 
    Active-Matrix Organic LED Display. In SID Tech. Dig. 1998.
}}
#### File{anchor:A2}
ACM.xsl - the file can be found in the [release:styles](15852) collection
#### Supported Types{anchor:A4}
The current version of the style supports the following types and subtypes.
* ArticleInAPeriodical
* Book
* BookSection
* ConferenceProceedings
* JournalArticle
* Misc
* Report
	* Thesis
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Variations{anchor:A5}
* You can change the look of the numbers in the first column of the bibliography by changing the **format** element of the first column _(column id="1")_. Note that you have to do this for each type separately. Some examples are:
{code:xml}
  <!-- Just a number (current implementation). Example: 1 -->
  <format>{%RefOrder%}</format>
  <!-- Number between round brackets. Example: (1) -->
  <format>{(%RefOrder%)}</format>
  <!-- Number between square brackets. Example: [1](1) -->
  <format>{[%RefOrder%](%RefOrder%)}</format>
{code:xml}