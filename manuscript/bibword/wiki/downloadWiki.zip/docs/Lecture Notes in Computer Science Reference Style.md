## Lecture Notes in Computer Science Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Based On](#A3)
* [Supported Types](#A4)
* [Remarks](#A5)
#### Description{anchor:A1}
Implementation of the Lecture Notes in Computer Science (LNCS) reference style. Sources are sorted based on their occurrence in the text.

Examples:
{{
9.  Rose, H.: In : A Course in Number Theory. Oxford Univ. Press, New York (1988)
10. Bul, B.: In : Theory Principles and Design of Magnetic Circuits. Energia Press, 
    Moscow, Russia (1964) 464
11. Sorin, W.: Optical Reflectometry for Component Characterization. In Derickson, D.,
    ed. : Fiber Optic Test and Measurement. Prentice-Hall, Englewood Cliffs (1998)
…
23. Delorme, F., others: Butt-joined DBR Laser With 15 nm Tunability Grown in Three 
    MOVPE Steps. Electron. Lett. 31(15), 1244-1245 (1995)
24. Casteldini, A., Cavallini, A., Fraboni, B., Fernandez, P., Piqueras, J.: Midgap Traps
    Related to Compensation Processes in CdTe Alloys. Phys. Rev. B. 56(23), 14897-14900 (1997)
}}
#### File{anchor:A2}
LNCS.xsl - the file can be found in the [release:styles](15852) collection
#### Based On{anchor:A3}
* BibTeX style for LNCS ([splncs.bst](http://www.springer.com/computer/lncs?SGWID=0-164-7-72376-0))
#### Supported Types{anchor:A4}
The current version of the style supports the following types and subtypes.
* ArticleInAPeriodical
* Book
* BookSection
* ConferenceProceedings
* DocumentFromInternetSite
* ElectronicSource
* InternetSite
* JournalArticle
* Misc
* Report
	* Thesis
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Remarks{anchor:A5}
* LNCS does not provide formatting guidelines for any type of electronic content. Hence, the formatting rules provided in here are the authors own preference.
