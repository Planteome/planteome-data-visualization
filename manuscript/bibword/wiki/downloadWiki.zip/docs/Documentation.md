### The Styles
* [Styles](Styles)
	* [Download](Styles#Download)
	* [Installation](Styles#Installation)
* [Frequently Asked Questions](Styles_FAQ)
### The Tools
* [BibWord](BibWord) : the template on top of which the styles are created
* [BibWord Extender](BibWord-Extender) : the external application used to add extra functionality like year suffices to the Word bibliography tools
* [release:BibType](15976) : an application to extend the available fields and types
### Creating and Editing BibWord Styles
* [Format Strings](BibWord-Format-Strings)
* [Formatting a Set of Contributors](BibWord-Format-Contributors)