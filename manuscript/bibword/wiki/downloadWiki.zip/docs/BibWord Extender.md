## BibWord Extender
[release:Latest version (v.2.0)](24823)
#### Introduction
Microsoft Word handles the formatting of citations in a rather odd way. Each citation is seen as a separate entity, i.e., a citation is mostly unrelated to the other citations and completely unrelated to any bibliography in the same document. Although this approach might have some advantages, it also has a lot of drawbacks. For example, it is not possible to communicate the position of a source in a bibliography to its citation. Hence, the possibilities for numbered references are rather limited.

_BibWord Extender_ is an external tool which allows certain styles developed using the [BibWord](BibWord) template to overcome some of the shortcomings in the Word bibliography system. The tool interacts with a special part of a BibWord bibliography stylesheet and updates all sources in a Word document.
#### Extended Sources
Using _BibWord Extender_, the following extra nodes can be added to a source:
* **BibOrder**: a variable indicating the order of a source in a bibliography. This can be useful for in-text citations as Word only allows the use of the in-text reference order. To use this variable, the _sortkey_ element has to be defined by the style. 
* **YearSuffix**: a variable providing a one character suffix for years. This can be useful if multiple works written by the same author in the same year are cited in the text and are otherwise indistinguishable. To use this variable, both the _sortkey_ and the _yearsuffix_ element have to be defined by the style.
More information on the variables can be found in the 'BibWord Guide' which comes with [BibWord](BibWord).
#### Usage
The common way to work with the BibWord Extender is:
# Create your document.
# Select the bibliography style you want to use.
# Save your document and close Word 2007.
# Run the BibWord Extender tool.
# Open your document and select the style again (so all citation and bibliography fields get updated).
#### BibWord Extender on Mac OS X
As of version 2.0, BibWord Extender can be used on Mac OS X through Mono. See the latest release on how to do so.
#### Naming Convention
Although you can name styles which require BibWord Extender any way you want, it would be nice if they all ended with a star ({"*"}). That way users might more easily realise that they need an extra tool if they want their in-text citations and bibliography to be formatted correctly.
#### History
See [project history](History#Extender).