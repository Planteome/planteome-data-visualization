## BibWord
[release:Latest version (v.2.9)](104366)
#### Introduction
Starting with Microsoft Word 2007, customers with knowledge of XML and XSLT can create their own stylesheets to format citation and bibliography fields within their Word documents. Although still in its infancy, the technology looks very promising for everyone interested in writing scientific articles. Unfortunately, the technology is poorly documented and for most customers the stylesheets which come with Word are overly complex to be used as a guideline for developing new stylesheets.

_BibWord_ is an XSLT template which attempts to simplify the process of creating new bibliography styles. With the help of the _BibWord Extender_ tool, the functionality of the bibliography styles can even be extended.
#### Advantages
Some of the advantages of the _BibWord_ approach are:
* the elimination of the need to understand and write XSLT;
* the introduction of a simple conditional language to format reference data depending on its availability;
* the grouping of all formatting information allowing users to update or change existing BibWord styles in seconds;
* the possibility to use numerical in-text citations based on the order of the bibliography entries through the [BibWord Extender](BibWord-Extender) tool;
* the possibility to use year suffices if the same author published multiple works in the same year through the [BibWord Extender](BibWord-Extender) tool. 
#### Information
More information on the formatting capabilities of _BibWord_ can be found:
* in the 'BibWord Guide' which comes with each release;
* in the style template which comes with an example for formatting books;
* in a number of publically available styles implemented so far;
* in this [tutorial](Tutorial).
#### License
_BibWord_ is currently [licensed](http://www.codeplex.com/bibliography/license) under the MIT license. If you have problems with this license and still want to use _BibWord_, please contact the project coordinators to discuss alternative licensing policies. 
#### History
See [project history](History#BibWord).