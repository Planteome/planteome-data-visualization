## American Medical Association Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Based On](#A3)
* [Supported Types](#A4)
* [Variations](#A5)
#### Description{anchor:A1}
Implementation of the American Medical Association (AMA) reference style.

Examples:
{{
 4. Beebe NH F. TeX User Group Bibliography Archive. August 2006. Available at: 
    http://www.math.utah.edu:8080/pub/tex/bib/index-table.html.
 5. Cullity BD. Introduction to Magnetic Materials. Reading: Addison-Wesley; 1972.
    ...
10. Candy JC, Temes, GC, eds. Oversampling Delta-Sigma Data Converters Theory, 
    Design and Simulation. New York: IEEE Press.; 1992.
}}
#### File{anchor:A2}
AMA.xsl - the file can be found in the [release:styles](15852) collection
#### Based On{anchor:A3}
* JAMA style in [Endnote](http://www.endnote.com)
#### Supported Types{anchor:A4}
The current version of the style supports the following types and subtypes.
* ArticleInAPeriodical
* Book
* BookSection
* ConferenceProceedings
* Case
* DocumentFromInternetSite
* Film
* InternetSite
* JournalArticle
* Misc
* Patent
* Report
	* Thesis
* SoundRecording
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Variations{anchor:A5}
* You can change the surrounding brackets for in-text citations by changing the contents of the **openbracket** and **closebracket** elements. 
{code:xml}
  <citation>
    <openbracket></openbracket>
    <closebracket></closebracket>
    ...
  </citation>
{code:xml}
* You can change the look of the numbers in the first column of the bibliography by changing the **format** element of the first column _(column id="1")_. Note that you have to do this for each type separately. Some examples are:
{code:xml}
  <!-- Number followed by a period (current implementation). Example: 1. -->
  <format>{%RefOrder%.}</format>
  <!-- Number between round brackets. Example: (1) -->
  <format>{(%RefOrder%)}</format>
  <!-- Number between square brackets. Example: [1](1) -->
  <format>{[%RefOrder%](%RefOrder%)}</format>
{code:xml}