## Council of Science Editors Reference Style
#### Table of Content
* [Description](#A1)
* [Files](#A2)
* [Requirements](#A3)
* [Based On](#A4)
* [Supported Types](#A5)
* [Variations](#A6)
#### Description{anchor:A1}
Implementation of the Council of Science Editors (CSE) reference style. There are three versions of this style:
* _Citation Sequence_: numeric in-text citation based on the order of appearance in the text;
* _Name Sequence_: numeric in-text citation based on the position of the source within the alphabetically ordered bibliography;
* _Name Year_: classic author-date citation system.
Currently, only an implementation of the first two is available.

As the current version of the bibliography tools in Word 2007 does not support to order a bibliography and use the position as in-text citation, the [release:BibOrder](17130) tool is needed to achieve the _Name Sequence_ version of the style.

Examples:
{{
11  Sorin WV. Optical Reflectometry for Component Characterization. In: Derickson D,
    editor. Fiber Optic Test and Measurement. Englewood Cliffs (NJ): Prentice-Hall; 1998.
12  Anderson JB, Tepe K. Properties of the Tailbiting BCJR Decoder. In: Codes, Systems
    and Graphical Models. New York: Springer-Verlag; 2000.
13  Hedelin P, Knagenhjelm P, Skoglund M. Theory for Transmission of Vector Quantization
    Data. In: Kleijn WB, Paliwal KK, editors. Speech Coding and Synthesis. Amsterdam: Elsevier
    Science; 1995. p. 347-396.
}}
#### Files{anchor:A2}
* CSECitSeq.xsl - Citation Sequence version of the style.
* CSENameSeq.xsl - Name Sequence version of the style.
Both files can be found in the [release:styles](15852) collection.
#### Requirements{anchor:A3}
* [release:BibOrder](17130)
#### Based On{anchor:A4}
* [http://www.dianahacker.com/resdoc/p04_c11_s2.html](http://www.dianahacker.com/resdoc/p04_c11_s2.html).
#### Supported Types{anchor:A5}
The current versions of the style support the following types and subtypes:
* ArticleInAPeriodical
* Book
	* ElectronicBook
* BookSection
	* ElectronicBookSection
* ConferenceProceedings
* DocumentFromInternetSite
* ElectronicSource
* Film
* InternetSite
* JournalArticle 
* Patent
* Report
	* Thesis
* SoundRecording
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Variations{anchor:A6}
* You can change the surrounding brackets for in-text citations by changing the contents of the **openbracket** and **closebracket** elements. 
{code:xml}
  <citation>
    <openbracket>[</openbracket>
    <closebracket>]</closebracket>
    ...
  </citation>
{code:xml}
* You can change the look of the numbers in the first column of the bibliography by changing the **format** element of the first column _(column id="1")_. Note that you have to do this for each type separately. Some examples are:
{code:xml}
  <!-- Number between square brackets (current implementation). Example: 1 -->
  <format>{%RefOrder%}</format>
  <!-- Number between round brackets. Example: (1) -->
  <format>{(%RefOrder%)}</format>
  <!-- Number followed by a period. Example: 1. -->
  <format>{%RefOrder%.}</format>
{code:xml}