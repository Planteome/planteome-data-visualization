## Styles
[release:Latest version of all styles](15852)
#### Introduction
The main goal of this project is to collect and maintain a number of bibliography styles which can be used by Microsoft Word 2007 and later. Most styles are either created using [BibWord](BibWord) or derived from the styles which come with Microsoft Word. 

Each family of styles comes with its own release page. Whenever bugs are fixed or new types are added, the same release gets updated.

Everybody who wants to submit a style can do so by contacting one of the project coordinators. The only requirement for putting a style on the project page, is that you release your style under the MIT license. That basically allows people to do whatever they want with your style as long as they give you credit for it.
#### Supported styles
The following list contains an overview of the current set of styles:
* [release:Associação Brasileira de Normas Técnicas](27212) (ABNT)
* [release:Association for Computing Machinery](19777) (ACM)
* [release:American Medical Society](25693) (ACS)
* [release:American Medical Association](19778) (AMA)
* [release:American Sociological Association](26892) (ASA)
* [release:Chicago Footnotes](20331) (beta - not in zip)
* [release:Council of Science Editors](19770) (CSE)
* [release:Harvard - AGPS](22931)
* [release:Harvard - Anglia](19783)
* [release:Harvard - Exeter](22890)
* [release:Harvard - Leeds](19776)
* [release:Humana Press](19809)
* [release:IEEE](19764)
* [release:Lecture Notes in Computer Science](19773) (LNCS)
* [release:Modern Humanities Research Association](19998) (MHRA)
* [release:Nature](26055)
* [release:Vancouver](19772)
{anchor:Download}
#### Download
You can download a zip file containing all styles from [release:here](15852).
{anchor:Installation}
#### Installation on Windows (Word 2007/2010/2013)
To use the bibliography styles, they have to be copied into the Microsoft Word bibliography style directory. This directory can vary depending on where Word is installed: 
##### Word 2007
{{
    <winword.exe directory>\Bibliography\Style
}} On most _32-bits_ machines with Microsoft Word 2007 this will be:

{{
    %programfiles%\Microsoft Office\Office12\Bibliography\Style
}}Once the styles are copied to the directory, they will show up every time Microsoft Word is opened.

##### Word 2010
{{
    <winword.exe directory>\Bibliography\Style
}} On most _32-bits_ machines with Microsoft Word 2010 this will be:

{{
    %programfiles%\Microsoft Office\Office14\Bibliography\Style
}}Once the styles are copied to the directory, they will show up every time Microsoft Word is opened.

##### Word 2013
{{
    <user directory>\AppData\Roaming\Microsoft\Bibliography\Style
}} On most machines with Micrososft Word 2013 this will be:

{{
    %userprofile%\AppData\Roaming\Microsoft\Bibliography\Style
}}Once the styles are copied to the directory, they will show up every time Microsoft Word is opened.

##### Word 365
{{
    %AppData%\Microsoft\Templates\LiveContent\15\Managed\Word Document Bibliography Styles
}}Once the styles are copied to the directory, they will show up every time Microsoft Word is opened.

**Remark:** the _types.xml_ included with the stylesheets should be used in combination with [release:BibType](15976) to create some extra fields for the different types.
#### Installation for Word 2008 or 2011 for Mac
To use the bibliography styles, right-click on Microsoft Word 2008 and select show package contents. Put the files in:

{{
    Contents/Resources/Style/
}} On most Macs with Microsoft Word 2008 this will be:

{{
    /Applications/Microsoft Office 2008/Microsoft Word.app/Contents/Resources/Style/
}}
#### Installation for Word 2016 for Mac (version 15.17.0 and up)
To use the bibliography styles, place them in the following folder

{{
    /Library/AppSupport/Microsoft/Office365/Citations/
}}
{anchor:FAQ}
#### FAQ
A number of frequently asked questions regarding the style linked from this page can be found [here](Styles_FAQ).