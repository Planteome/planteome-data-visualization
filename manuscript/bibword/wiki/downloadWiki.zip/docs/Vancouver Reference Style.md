## Vancouver Reference Style
#### Table of Content
* [Description](#A1)
* [File](#A2)
* [Based On](#A3)
* [Supported Types](#A4)
* [Variations](#A5)
#### Description{anchor:A1}
Implementation of the Vancouver reference style. This style uses numeric in-text citations based on the order of the first appearance of a source in the text.

Examples:
{{
 (1) Breckling J, editor. The Analysis of Directional Time Series: Applications to Wind Speed and 
     Direction Berlin: Springer; 1989.
 (2) Rose HE. In A Course in Number Theory. New York: Oxford Univ. Press; 1988.
 (3) Bul BK. In Theory Principles and Design of Magnetic Circuits. Moscow: Energia Press; 1964.
     p. 464.
 (4) Sorin WV. Optical Reflectometry for Component Characterization. In Derickson D, editor. Fiber 
     Optic Test and Measurement. Englewood Cliffs: Prentice-Hall; 1998.
     ...
(10) Anderson JB, Tepe K. Properties of the Tailbiting BCJR Decoder. In Codes, Systems and 
     Graphical Models. New York: Springer-Verlag; 2000.
(11) Hedelin P, Knagenhjelm P, Skoglund M. Theory for Transmission of Vector Quantization Data. 
     In Kleijn WB, Paliwal KK, editors. Speech Coding and Synthesis. Amsterdam: Elsevier Science; 
     1995. p. 347-396.
}}
#### File{anchor:A2}
vancouver.xsl - the file can be found in the [release:styles](15852) collection
#### Based On{anchor:A3}
* [http://www.library.uq.edu.au/training/citation/vancouv.pdf](http://www.library.uq.edu.au/training/citation/vancouv.pdf)
* [http://www.library.uwa.edu.au/education_training_and_support/guides/vancouver_citation_style](http://www.library.uwa.edu.au/education_training_and_support/guides/vancouver_citation_style)
* [http://www.endnote.com](http://www.endnote.com)
#### Supported Types{anchor:A4}
The current version of the style supports the following types and subtypes.
* ArticleInAPeriodical
* Book
* BookSection
* ConferenceProceedings
* DocumentFromInternetSite
* ElectronicSource
* InternetSite
* JournalArticle 
	* ElectronicArticle
* Misc
* Patent
* Report
	* Thesis
_**Note:**_ To use the subtypes _(e.g. Thesis)_, enter the data using the base type _(e.g. Report)_ and set the **Type** field of the source to the value of the subtype _(e.g. Thesis)_.
#### Variations{anchor:A5}
* You can change the surrounding brackets for in-text citations by changing the contents of the **openbracket** and **closebracket** elements. 
{code:xml}
  <citation>
    <openbracket>(</openbracket>
    <closebracket>)</closebracket>
    ...
  </citation>
{code:xml}
* You can change the look of the numbers in the first column of the bibliography by changing the **format** element of the first column _(column id="1")_. Note that you have to do this for each type separately. Some examples are:
{code:xml}
  <!-- Number between round brackets (current implementation). Example: (1) -->
  <format>{(%RefOrder%)}</format>
  <!-- Number between square brackets. Example: [1](1) -->
  <format>{[%RefOrder%](%RefOrder%)}</format>
  <!-- Number followed by a period. Example: 1. -->
  <format>{%RefOrder%.}</format>
{code:xml}